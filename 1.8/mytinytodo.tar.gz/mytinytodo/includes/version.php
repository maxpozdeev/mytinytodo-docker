<?php

namespace mytinytodo;

class Version
{
    const VERSION = '1.8.1';
    const DB_VERSION = '1.8';
}
