<?php

namespace mytinytodo;

class Version
{
    const VERSION = '1.8.3';
    const DB_VERSION = '1.8';
}
