<?php

namespace mytinytodo;

class Version
{
    const VERSION = '1.7.3';
    const DB_VERSION = '1.7';
}
